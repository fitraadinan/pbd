

<?php $__env->startSection('content'); ?>
    
<div class="page-title">
    <h3>Data Club</h3>
</div>
<section class="section">
    
    <div class="row mb-4">
        <div class="col-md-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(url('modul/club/add')); ?>"><h4 class="card-title">
                                        
                    <button class="btn btn-primary">Tambah</button>
                    </h4></a>
                </div>

                <div class="card-body">
                    <div class="table table-responsive">
                        <table class='table table-striped' id="table1"> 
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Club</th>
                                    <th>Hari</th>
                                    <th>Jam</th>
                                    <th>Lab</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($clubs->club_name); ?></td>
                                        <td><?php echo e($clubs->hari); ?></td>
                                        <td><?php echo e($clubs->jam); ?></td>
                                        <td><?php echo e($clubs->lab->lab_name); ?></td>
                                        <td>
                                            <div class="btn-group">

                                            <a href="<?php echo e(url('/modul/club/edit/'.$clubs->id)); ?>"><button class="btn btn-sm btn-warning"> <i data-feather="edit" width="20"></i></button></a>   
                                            <button class="btn btn-sm btn-danger" id="btn" type="button" data-toggle="modal" data-target="#modaldeleteclub-<?php echo e($clubs->id); ?>"> <i data-feather="trash" width="20"></i></button>  

                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- Modal -->
                    <div class="modal fade" id="modaldeleteclub-<?php echo e($clubs->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modaldeleteLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="modaldeleteLabel">Hapus Data Club <?php echo e($clubs->club_name); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                            Apakan Anda yakin ingin menghapus data club <?php echo e($clubs->club_name); ?>?
                            <input type="hidden" name="club" value="<?php echo e($clubs->id); ?>">
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                            <a href="/modul/club/delete/<?php echo e($clubs->id); ?>"><button type="button" class="btn btn-primary">Yakin</button></a>
                            </div>
                        </div>
                        </div>
                    </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gatra\OneDrive\Desktop\Kuliah\Pemrograman Basis Data\pbd\resources\views/club/index.blade.php ENDPATH**/ ?>
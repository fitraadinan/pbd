@extends('layouts.style')

@section('content')
    
    <div class="page-title">
        <h3>Dashboard</h3>
        <p class="text-subtitle text-muted">Hello</p>
    </div>
    <section class="section">
        
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card" style="min-height:300px">
                    <div class="card-header">
                        <h3 class='card-heading p-1 pl-3'>Selamat Datang</h3>
                    </div>
                    <div class="card-body" >
                        <div class="row">
                            <h1>Aplikasi Pendataan Anggota CERC</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection